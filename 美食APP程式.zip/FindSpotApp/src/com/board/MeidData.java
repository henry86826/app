package com.board;

public class MeidData  
{
    public String id, data1, data2, data3, data4, data5, data6, data7, data8;
}
