package com.xml;


public class FoodNoteStruct 
{
	
  public String id;
  public String Name;
  public String Website;
  public String Class1;
  public String Py;
  public String Px;
  public String Gov;
  public String Opentime;
  public String Travellinginfo;
  public String Zipcode;
  public String Add;
  public String Tel;
  public String Description;
  public String Img;
 
}