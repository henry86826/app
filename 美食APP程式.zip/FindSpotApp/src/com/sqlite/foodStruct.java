package com.sqlite;

import java.util.ArrayList;


public class foodStruct 
{
	
  public String classify;
  public ArrayList<String> foodname = new ArrayList<String>();
  public ArrayList<Integer> hot = new ArrayList<Integer>();
 
}