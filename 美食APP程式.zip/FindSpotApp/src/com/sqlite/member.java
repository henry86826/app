package com.sqlite;

public class member
{
	public static final String ID = "aid";
	public static final String NAME = "name";
	public static final String SEX = "sex";
	public static final String WEIGHT = "weight";
	public static final String HEIGHT = "height";
	public static final String WAIST = "waist";
	public static final String AGE = "age";
	public static final String RDATE = "date";
  
	public String id;
	public String sex;
	public String name;
	public String weight;
 	public String height;
	public String waist;	
	public String age;	
	public String rdate;
 
}
