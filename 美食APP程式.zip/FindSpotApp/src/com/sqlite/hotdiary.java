package com.sqlite;

public class hotdiary
{
	public static final String ID = "aid";
	public static final String DITEM = "ditem";
	public static final String SITEM = "sitem";
	public static final String DHOT = "dhot";
	public static final String SHOT = "shot";
	public static final String RDATE = "rdate";
	public static final String USER = "user";
  
	public String id;
	public String ditem;
	public String sitem;
	public String dhot;
	public String shot;
	public String rdate;
	public String user; 
}
