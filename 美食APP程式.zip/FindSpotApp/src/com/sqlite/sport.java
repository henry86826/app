package com.sqlite;

public class sport
{
	public static final String ID = "aid";
	public static final String SPORT = "name";
	public static final String ITEM = "item";
	public static final String RDATE = "date";
	public static final String USER = "user";
  
	public String id;
	public String name;
	public String item;
	public String rdate;
	public String user; 
}
