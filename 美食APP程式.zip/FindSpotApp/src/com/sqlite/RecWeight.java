package com.sqlite;

public class RecWeight
{
	public static final String ID = "aid";
	public static final String WEIGHT = "weight";
	public static final String PIC = "picture";
	public static final String RDATE = "date";
	public static final String USER = "user";
  
	public String id;
	public String weight;
	public String pic;
	public String rdate;
	public String user; 
}
