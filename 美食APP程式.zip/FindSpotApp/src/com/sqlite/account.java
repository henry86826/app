package com.sqlite;

public class account 
{
	public static final String ID = "aid";
	public static final String NAME = "name";
  public static final String SEX = "sex";
	public static final String AGE = "age";
  public static final String HEIGHT = "height";
  public static final String WEIGHT = "weight";
  

	public String id;
	public String name;
	public String sex;
  public String age;
  public String height;
  public String weight;
  
}
